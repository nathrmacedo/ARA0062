<!doctype html>

        <html lang="pt-br">
        
        <head>
            <meta charset="UTF-8">
            <title>Majin Donuts</title>
        
            <link rel="stylesheet" href="estilo.css">
        </head>
        
        <body>
            <header id="topo">
                <div id="logo">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNwnVHJujfF8RgjjvJ4L3YIWtsncAbtwR83g&usqp=CAU">
                </div>
                <h1>Majin Donuts</h1>
                <nav id="menu">
                    <a href="#"> Inicio </a> |
                    <a href="https://www.instagram.com/majindonuts/" target=_blank>Instagram </a> |
                    <a href="login.html"> Login </a> |
                    <a href="menu.php"> Cadastro blog (Cardápio) </a> |
                    <hr>
                </nav>
            </header>
            <h2>Cardápio</h2>
        
            <table>
                <section id="cardapio">
                    <div class="tradicional">
                        <div class="thead">
                            <tr>
                                <th>Tradicionais</th>
                                <th>Valor</th>
                            </tr>
                        </div>
        
                        <div class="tbody">
                            <tr>
                                <td>Tortuguita</td>
                                <td>5$</td>
        
                            </tr>
                            <tr>
                                <td>Kit Kat</td>
                                <td>5$</td>
                            </tr>
                            <tr>
                                <td>Óreo</td>
                                <td>5$</td>
                            </tr>
                            <tr>
                                <td>Choc Preto c/Amendoim</td>
                                <td>5$</td>
                            </tr>
                            <tr>
                                <td>Simpson</td>
                                <td>5$</td>
                            </tr>
                        </div>
                    </div>
                </section>
                <section id="cadapio">
                    <div class="recheados">
                        <div class="thead">
                            <tr>
                                <th>Recheados</th>
                                <th>Valor</th>
                            </tr>
                        </div>
                        <div class="tbody">
                            <tr>
                                <td>Nutella c/Ninho</td>
                                <td>7$</td>
                            </tr>
                            <tr>
                                <td>Churros</td>
                                <td>6$</td>
                            </tr>
                            <tr>
                                <td>Brigadeiro</td>
                                <td>6$</td>
                            </tr>
                            <tr>
                                <td>Creme Belga</td>
                                <td>6$</td>
                            </tr>
                            <tr>
                                <td>Óreo</td>
                                <td>6$</td>
                            </tr>
                        </div>
                    </div>
                </section>
        
            </table>
        
            <hr>
          
            <div class="row">
        
                <?php
                    include_once("servico/Bd.php");
                    
                    $bd = new Bd();
                    
                    $sql = "SELECT * FROM `blog`";
                    
                    foreach ($bd->query($sql) as $row) {
                       
                       echo  '
                        <div class="card">
                          <div class="card-body">
                            <h5 class="card-title">'.$row['titulo'].'</h5>
                            <p class="card-text">'.substr($row['corpo'],0,100).' ...</p>
                            <a href="#" class="card-link">Leia mais</a>
                          </div>
                        </div>
                       ';
                       
                    }
                
                ?>
            </div>
        </body>
        
        </html>
        
   